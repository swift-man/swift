//: Playground - noun: a place where people can play

import Foundation

enum UpbitMarket {
    case KRW, BTC, ETH, USDT
}

let codeName: UpbitMarket = .KRW

print(codeName) //KRW

enum MinuteType: Int {
    case second_1 = 1
    case second_3 = 3
    case second_5 = 5
    case second_10 = 10
    case second_15 = 15
    case second_30 = 30
    case second_60 = 60
    case second_240 = 240
}

let minutes: MinuteType = .second_10

print(minutes.rawValue) //10
